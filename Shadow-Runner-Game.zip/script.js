const authScreen = document.getElementById("authScreen");
const homeScreen = document.getElementById("homeScreen");
const gameScreen = document.getElementById("gameScreen");

const nameInput = document.getElementById("nameInput");
const passwordInput = document.getElementById("passwordInput");
const createBtn = document.getElementById("createBtn");
const authMessage = document.getElementById("authMessage");

const playerName = document.getElementById("playerName");
const bestScoreEl = document.getElementById("bestScore");
const bestCoinsEl = document.getElementById("bestCoins");

const startBtn = document.getElementById("startBtn");
const logoutBtn = document.getElementById("logoutBtn");
const modeButtons = document.querySelectorAll(".mode-btn");

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const scoreEl = document.getElementById("score");
const coinsEl = document.getElementById("coins");
const livesEl = document.getElementById("lives");
const levelEl = document.getElementById("level");

const pauseBtn = document.getElementById("pauseBtn");
const pauseOverlay = document.getElementById("pauseOverlay");
const resumeBtn = document.getElementById("resumeBtn");
const pauseMenuBtn = document.getElementById("pauseMenuBtn");

const gameOverOverlay = document.getElementById("gameOverOverlay");
const finalScore = document.getElementById("finalScore");
const finalCoins = document.getElementById("finalCoins");
const retryBtn = document.getElementById("retryBtn");
const gameOverMenuBtn = document.getElementById("gameOverMenuBtn");

let selectedMode = "classic";
let player = null;
let gameRunning = false;
let paused = false;
let animationId = null;
let lastTime = 0;
let elapsed = 0;
let score = 0;
let coins = 0;
let lives = 3;
let level = 1;
let speed = 330;
let obstacleTimer = 0;
let coinTimer = 0;
let stars = [];
let obstacles = [];
let coinObjects = [];
let particles = [];
let groundY = 0;
let modeTime = 0;

const ACCOUNT_KEY = "shadowRunnerAccount";
const BEST_SCORE_KEY = "shadowRunnerBestScore";
const BEST_COINS_KEY = "shadowRunnerBestCoins";

function showScreen(screen) {
  [authScreen, homeScreen, gameScreen].forEach(s => s.classList.add("hidden"));
  screen.classList.remove("hidden");
}

function loadAccount() {
  try {
    return JSON.parse(localStorage.getItem(ACCOUNT_KEY));
  } catch {
    return null;
  }
}

function refreshHome() {
  const account = loadAccount();
  if (!account) return;
  playerName.textContent = account.name;
  bestScoreEl.textContent = localStorage.getItem(BEST_SCORE_KEY) || "0";
  bestCoinsEl.textContent = localStorage.getItem(BEST_COINS_KEY) || "0";
}

createBtn.addEventListener("click", createAccount);

[nameInput, passwordInput].forEach(input => {
  input.addEventListener("keydown", e => {
    if (e.key === "Enter") createAccount();
  });
});

function createAccount() {
  const name = nameInput.value.trim();
  const password = passwordInput.value;

  if (name.length < 2) {
    authMessage.textContent = "Please enter a name with at least 2 characters.";
    return;
  }

  if (password.length < 4) {
    authMessage.textContent = "Password must be at least 4 characters.";
    return;
  }

  localStorage.setItem(ACCOUNT_KEY, JSON.stringify({ name, password }));
  localStorage.setItem(BEST_SCORE_KEY, localStorage.getItem(BEST_SCORE_KEY) || "0");
  localStorage.setItem(BEST_COINS_KEY, localStorage.getItem(BEST_COINS_KEY) || "0");

  refreshHome();
  showScreen(homeScreen);
}

logoutBtn.addEventListener("click", () => {
  showScreen(authScreen);
  passwordInput.value = "";
  authMessage.textContent = "";
});

modeButtons.forEach(button => {
  button.addEventListener("click", () => {
    modeButtons.forEach(b => b.classList.remove("selected"));
    button.classList.add("selected");
    selectedMode = button.dataset.mode;
  });
});

startBtn.addEventListener("click", startGame);
retryBtn.addEventListener("click", startGame);

pauseBtn.addEventListener("click", togglePause);
resumeBtn.addEventListener("click", togglePause);

pauseMenuBtn.addEventListener("click", () => {
  endToMenu();
});

gameOverMenuBtn.addEventListener("click", () => {
  endToMenu();
});

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.floor(rect.width * dpr);
  canvas.height = Math.floor(rect.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  groundY = rect.height - 85;
}
window.addEventListener("resize", resizeCanvas);

function startGame() {
  showScreen(gameScreen);
  requestAnimationFrame(() => {
    resizeCanvas();
    resetGame();
    gameRunning = true;
    paused = false;
    pauseOverlay.classList.add("hidden");
    gameOverOverlay.classList.add("hidden");
    lastTime = performance.now();
    animationId = requestAnimationFrame(gameLoop);
  });
}

function resetGame() {
  score = 0;
  coins = 0;
  lives = selectedMode === "challenge" ? 3 : 1;
  level = 1;
  speed = 330;
  elapsed = 0;
  modeTime = selectedMode === "timetrial" ? 60 : 0;
  obstacleTimer = 0.9;
  coinTimer = 0.7;
  obstacles = [];
  coinObjects = [];
  particles = [];

  player = {
    x: Math.max(55, canvas.clientWidth * 0.18),
    y: 0,
    w: 42,
    h: 62,
    vy: 0,
    grounded: true,
    invincible: 0
  };

  player.y = groundY - player.h;

  stars = Array.from({ length: 90 }, () => ({
    x: Math.random() * canvas.clientWidth,
    y: Math.random() * Math.max(100, groundY - 30),
    r: Math.random() * 1.7 + .3,
    s: Math.random() * 25 + 8
  }));

  updateHUD();
}

function gameLoop(now) {
  if (!gameRunning) return;

  const dt = Math.min((now - lastTime) / 1000, 0.035);
  lastTime = now;

  if (!paused) {
    update(dt);
    draw();
  }

  animationId = requestAnimationFrame(gameLoop);
}

function update(dt) {
  elapsed += dt;
  if (selectedMode === "timetrial") {
    modeTime -= dt;
    if (modeTime <= 0) {
      gameOver();
      return;
    }
  }

  level = Math.min(20, 1 + Math.floor(elapsed / 12));
  speed = 330 + (level - 1) * 24;

  score += dt * (12 + level * 1.5);

  if (player.invincible > 0) player.invincible -= dt;

  // Player physics
  player.vy += 1850 * dt;
  player.y += player.vy * dt;

  if (player.y + player.h >= groundY) {
    player.y = groundY - player.h;
    player.vy = 0;
    player.grounded = true;
  } else {
    player.grounded = false;
  }

  // Spawn obstacles
  obstacleTimer -= dt;
  if (obstacleTimer <= 0) {
    spawnObstacle();
    obstacleTimer = Math.max(.62, 1.35 - level * .035) + Math.random() * .5;
  }

  // Spawn coins
  coinTimer -= dt;
  if (coinTimer <= 0) {
    spawnCoinLine();
    coinTimer = 1.2 + Math.random() * 1.1;
  }

  obstacles.forEach(o => o.x -= speed * dt);
  coinObjects.forEach(c => {
    c.x -= speed * dt;
    c.spin += dt * 7;
  });

  obstacles = obstacles.filter(o => o.x + o.w > -50);
  coinObjects = coinObjects.filter(c => c.x > -50);

  // Star movement
  stars.forEach(s => {
    s.x -= s.s * dt;
    if (s.x < -5) {
      s.x = canvas.clientWidth + 5;
      s.y = Math.random() * Math.max(100, groundY - 30);
    }
  });

  checkCollisions();
  updateParticles(dt);
  updateHUD();
}

function spawnObstacle() {
  const tall = Math.random() > .5;
  const h = tall ? 64 + Math.random() * 22 : 40 + Math.random() * 18;
  const w = 32 + Math.random() * 20;

  obstacles.push({
    x: canvas.clientWidth + 30,
    y: groundY - h,
    w,
    h,
    type: tall ? "spike" : "block"
  });
}

function spawnCoinLine() {
  const count = 3 + Math.floor(Math.random() * 3);
  const baseY = groundY - 110 - Math.random() * 100;

  for (let i = 0; i < count; i++) {
    coinObjects.push({
      x: canvas.clientWidth + 35 + i * 42,
      y: baseY + Math.sin(i * .8) * 18,
      r: 11,
      spin: Math.random() * 6
    });
  }
}

function checkCollisions() {
  const p = {
    x: player.x + 7,
    y: player.y + 5,
    w: player.w - 14,
    h: player.h - 8
  };

  for (const o of obstacles) {
    if (rectsOverlap(p, o)) {
      if (player.invincible <= 0) {
        lives--;
        player.invincible = 1.2;
        createBurst(player.x + player.w / 2, player.y + player.h / 2, 18);
        if (lives <= 0) {
          gameOver();
          return;
        }
      }
    }
  }

  coinObjects = coinObjects.filter(c => {
    const hit = circleRect(c.x, c.y, c.r, p);
    if (hit) {
      coins++;
      score += 35;
      createBurst(c.x, c.y, 8);
      return false;
    }
    return true;
  });
}

function rectsOverlap(a, b) {
  return a.x < b.x + b.w &&
         a.x + a.w > b.x &&
         a.y < b.y + b.h &&
         a.y + a.h > b.y;
}

function circleRect(cx, cy, r, rect) {
  const closestX = Math.max(rect.x, Math.min(cx, rect.x + rect.w));
  const closestY = Math.max(rect.y, Math.min(cy, rect.y + rect.h));
  const dx = cx - closestX;
  const dy = cy - closestY;
  return dx * dx + dy * dy < r * r;
}

function jump() {
  if (!gameRunning || paused || !player || !player.grounded) return;
  player.vy = -720;
  player.grounded = false;
  createBurst(player.x + player.w / 2, groundY, 7);
}

function movePlayer(dir) {
  if (!gameRunning || paused || !player) return;
  player.x += dir * 45;
  player.x = Math.max(10, Math.min(canvas.clientWidth - player.w - 10, player.x));
}

document.addEventListener("keydown", e => {
  if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") {
    e.preventDefault();
    jump();
  }
  if (e.code === "ArrowLeft" || e.code === "KeyA") movePlayer(-1);
  if (e.code === "ArrowRight" || e.code === "KeyD") movePlayer(1);
  if (e.code === "Escape") togglePause();
});

document.getElementById("jumpBtn").addEventListener("pointerdown", jump);
document.getElementById("leftBtn").addEventListener("pointerdown", () => movePlayer(-1));
document.getElementById("rightBtn").addEventListener("pointerdown", () => movePlayer(1));

function togglePause() {
  if (!gameRunning || gameOverOverlay.classList.contains("hidden") === false) return;
  paused = !paused;
  pauseOverlay.classList.toggle("hidden", !paused);
}

function gameOver() {
  gameRunning = false;
  paused = false;

  finalScore.textContent = Math.floor(score);
  finalCoins.textContent = coins;

  const oldBest = Number(localStorage.getItem(BEST_SCORE_KEY) || 0);
  const oldCoins = Number(localStorage.getItem(BEST_COINS_KEY) || 0);

  if (Math.floor(score) > oldBest) localStorage.setItem(BEST_SCORE_KEY, Math.floor(score));
  if (coins > oldCoins) localStorage.setItem(BEST_COINS_KEY, coins);

  gameOverOverlay.classList.remove("hidden");
  draw();
}

function endToMenu() {
  gameRunning = false;
  paused = false;
  if (animationId) cancelAnimationFrame(animationId);
  refreshHome();
  showScreen(homeScreen);
}

function updateHUD() {
  scoreEl.textContent = Math.floor(score);
  coinsEl.textContent = coins;
  livesEl.textContent = lives;
  levelEl.textContent = level;
}

function draw() {
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;

  ctx.clearRect(0, 0, w, h);

  // Sky gradient
  const gradient = ctx.createLinearGradient(0, 0, 0, h);
  gradient.addColorStop(0, "#08051c");
  gradient.addColorStop(.55, "#11143a");
  gradient.addColorStop(1, "#05060d");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, w, h);

  // Moon
  ctx.beginPath();
  ctx.arc(w * .78, 85, 38, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(190,220,255,.85)";
  ctx.shadowBlur = 30;
  ctx.shadowColor = "#8fd8ff";
  ctx.fill();
  ctx.shadowBlur = 0;

  // Stars
  stars.forEach(s => {
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,.75)";
    ctx.fill();
  });

  drawCity(w, h);

  // Ground
  ctx.fillStyle = "#05060b";
  ctx.fillRect(0, groundY, w, h - groundY);

  ctx.strokeStyle = "rgba(66,217,255,.55)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, groundY);
  ctx.lineTo(w, groundY);
  ctx.stroke();

  // Moving road lines
  const offset = (elapsed * speed * .7) % 80;
  ctx.strokeStyle = "rgba(155,92,255,.25)";
  ctx.lineWidth = 3;
  for (let x = -offset; x < w; x += 80) {
    ctx.beginPath();
    ctx.moveTo(x, groundY + 45);
    ctx.lineTo(x + 35, groundY + 45);
    ctx.stroke();
  }

  coinObjects.forEach(drawCoin);
  obstacles.forEach(drawObstacle);
  drawPlayer();
  drawParticles();
}

function drawCity(w, h) {
  const base = groundY;
  const buildingW = 55;

  for (let x = 0; x < w + buildingW; x += buildingW) {
    const height = 60 + ((x * 17) % 140);
    ctx.fillStyle = x % 110 === 0 ? "#101229" : "#0c0f23";
    ctx.fillRect(x, base - height, buildingW - 7, height);

    for (let yy = base - height + 15; yy < base - 8; yy += 18) {
      if ((x + yy) % 3 === 0) {
        ctx.fillStyle = "rgba(66,217,255,.45)";
        ctx.fillRect(x + 9, yy, 7, 4);
      }
    }
  }
}

function drawPlayer() {
  if (!player) return;

  if (player.invincible > 0 && Math.floor(player.invincible * 12) % 2 === 0) return;

  const x = player.x;
  const y = player.y;

  // Shadow
  ctx.fillStyle = "rgba(0,0,0,.5)";
  ctx.beginPath();
  ctx.ellipse(x + player.w / 2, groundY + 3, 28, 7, 0, 0, Math.PI * 2);
  ctx.fill();

  // Glow
  ctx.shadowBlur = 18;
  ctx.shadowColor = "#9b5cff";

  // Head
  ctx.fillStyle = "#d9c8ff";
  ctx.beginPath();
  ctx.arc(x + 22, y + 14, 10, 0, Math.PI * 2);
  ctx.fill();

  // Hood/body
  ctx.fillStyle = "#151321";
  ctx.beginPath();
  ctx.roundRect(x + 7, y + 20, 31, 30, 8);
  ctx.fill();

  // Face mask
  ctx.fillStyle = "#5e48a5";
  ctx.fillRect(x + 12, y + 18, 21, 8);

  // Legs
  ctx.strokeStyle = "#0b0a11";
  ctx.lineWidth = 9;
  ctx.lineCap = "round";
  const legSwing = Math.sin(elapsed * 13) * 7;
  ctx.beginPath();
  ctx.moveTo(x + 18, y + 48);
  ctx.lineTo(x + 13 - legSwing, y + 62);
  ctx.moveTo(x + 28, y + 48);
  ctx.lineTo(x + 34 + legSwing, y + 62);
  ctx.stroke();

  // Arms
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(x + 11, y + 27);
  ctx.lineTo(x + 2, y + 38 + legSwing);
  ctx.moveTo(x + 34, y + 27);
  ctx.lineTo(x + 43, y + 38 - legSwing);
  ctx.stroke();

  ctx.shadowBlur = 0;
}

function drawObstacle(o) {
  ctx.save();
  ctx.shadowBlur = 15;
  ctx.shadowColor = "#ff3eaa";

  if (o.type === "spike") {
    ctx.fillStyle = "#ff3eaa";
    ctx.beginPath();
    ctx.moveTo(o.x, o.y + o.h);
    ctx.lineTo(o.x + o.w / 2, o.y);
    ctx.lineTo(o.x + o.w, o.y + o.h);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#25102d";
    ctx.beginPath();
    ctx.moveTo(o.x + 7, o.y + o.h - 4);
    ctx.lineTo(o.x + o.w / 2, o.y + 12);
    ctx.lineTo(o.x + o.w - 7, o.y + o.h - 4);
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.fillStyle = "#c62f92";
    ctx.fillRect(o.x, o.y, o.w, o.h);
    ctx.fillStyle = "#25102d";
    ctx.fillRect(o.x + 6, o.y + 7, o.w - 12, 7);
    ctx.fillRect(o.x + 6, o.y + 23, o.w - 12, 7);
  }

  ctx.restore();
}

function drawCoin(c) {
  ctx.save();
  ctx.translate(c.x, c.y);
  ctx.scale(Math.max(.25, Math.abs(Math.cos(c.spin))), 1);
  ctx.shadowBlur = 18;
  ctx.shadowColor = "#ffe36e";

  ctx.beginPath();
  ctx.arc(0, 0, c.r, 0, Math.PI * 2);
  ctx.fillStyle = "#ffd84d";
  ctx.fill();

  ctx.beginPath();
  ctx.arc(0, 0, c.r - 4, 0, Math.PI * 2);
  ctx.strokeStyle = "#fff4a6";
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.restore();
}

function createBurst(x, y, amount) {
  for (let i = 0; i < amount; i++) {
    particles.push({
      x, y,
      vx: (Math.random() - .5) * 220,
      vy: (Math.random() - .7) * 220,
      life: .5 + Math.random() * .5,
      size: 2 + Math.random() * 4
    });
  }
}

function updateParticles(dt) {
  particles.forEach(p => {
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vy += 300 * dt;
  });
  particles = particles.filter(p => p.life > 0);
}

function drawParticles() {
  particles.forEach(p => {
    ctx.globalAlpha = Math.max(0, p.life);
    ctx.fillStyle = "#b978ff";
    ctx.fillRect(p.x, p.y, p.size, p.size);
  });
  ctx.globalAlpha = 1;
}

// Start on account screen if no account exists.
if (loadAccount()) {
  refreshHome();
  showScreen(homeScreen);
} else {
  showScreen(authScreen);
}
