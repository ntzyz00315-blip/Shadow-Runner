SHADOW RUNNER
=============

Files:
- index.html
- style.css
- script.js

How to play:
1. Open index.html in a modern browser.
2. Create an account with a name and password.
3. Select a game mode.
4. Press START RUN.
5. Jump with SPACE / UP / W or the JUMP button.
6. Use LEFT/RIGHT or A/D to move.
7. Collect coins and avoid obstacles.

The game is a client-side demo. Account data and high scores are stored in browser localStorage.
Do not use the localStorage password approach for a real production login system.

The game loop uses requestAnimationFrame for browser animation.
